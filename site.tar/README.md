# Welcome to the Tiny Flappy Bird

Build walkthrough in this Youtube video:
[![Video preview](https://img.youtube.com/vi/mfk8Rk2eUJY/0.jpg)](https://www.youtube.com/watch?v=mfk8Rk2eUJY)
